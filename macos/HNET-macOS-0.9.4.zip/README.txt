HNET для macOS — быстрый режим (MVP)
===================================

ТРЕБОВАНИЯ
- macOS 13+ (Apple Silicon или Intel), интернет.
- HulyNet и другие VPN должны быть ВЫКЛЮЧЕНЫ: helper откажется подключаться,
  если default route уже идёт через utun/ppp.
- Приложение не нотаризовано Apple: первый запуск — правый клик по HNET.app →
  «Открыть» → «Открыть». После этого запускается обычным двойным кликом.

УСТАНОВКА
1. Распакуйте HNET.app и перетащите в /Applications (по желанию).
2. Откройте HNET.
3. Нажмите «Установить компонент» и введите пароль администратора ОДИН раз.
   Это ставит привилегированный helper /Library/PrivilegedHelperTools/dev.hnet.helper.
4. Скопируйте тикет входа в буфер и нажмите «+» в приложении
   (или вставьте вручную). Сохранённые тикеты появляются чипами.
5. Нажмите большую кнопку. Проверка: https://ifconfig.me должен показать
   <EXIT_IP> (exit netcup). Скорость проверяйте на speedtest.net.

ЧТО ДЕЛАЕТ HELPER
- поднимает utun, направляет весь IPv4-трафик в туннель;
- на время VPN отключает IPv6 на активном сервисе (защита от утечек);
- ставит DNS 1.1.1.1 и восстанавливает прежние настройки при отключении.

АВАРИЙНОЕ ВОССТАНОВЛЕНИЕ СЕТИ (если что-то пошло не так)
1) В приложении нажмите «Отключить».
2) Если не помогло — Terminal:
   sudo /Library/PrivilegedHelperTools/dev.hnet.helper restore
3) Если и это не помогло:
   sudo launchctl bootout system /Library/LaunchDaemons/dev.hnet.helper.plist
   sudo rm -f /Library/LaunchDaemons/dev.hnet.helper.plist
   sudo rm -f /Library/PrivilegedHelperTools/dev.hnet.helper
   sudo networksetup -setv6automatic "Wi-Fi"
   sudo networksetup -setdnsservers "Wi-Fi" Empty
   Перезагрузка Mac гарантированно возвращает сеть.
Лог helper: /var/log/hnet-helper.log

УДАЛЕНИЕ
   sudo /bin/sh /Applications/HNET.app/Contents/Resources/uninstall-helper.sh

ОГРАНИЧЕНИЯ MVP
- один клиент на IP 10.99.0.2 (несколько устройств одновременно конфликтуют);
- kill switch и IPv6-туннель пока нет; IPv6 на время VPN выключен;
- при sleep/wake и смене сети соединение может потребовать переподключения.
