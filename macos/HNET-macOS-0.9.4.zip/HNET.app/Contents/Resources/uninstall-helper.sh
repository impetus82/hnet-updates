#!/bin/sh
set -e
PLIST="/Library/LaunchDaemons/dev.hnet.helper.plist"
DEST="/Library/PrivilegedHelperTools/dev.hnet.helper"
UIDFILE="/Library/Application Support/dev.hnet.uid"
# client key намеренно НЕ удаляется: иначе устройство потеряет allowlist-доступ.
# Для полного удаления: uninstall-helper.sh --purge
launchctl bootout system "$PLIST" 2>/dev/null || true
rm -f "$PLIST" "$DEST" "$UIDFILE" /var/run/dev.hnet.helper.sock /var/run/dev.hnet.state.json
if [ "${1:-}" = "--purge" ]; then
    rm -f "/Library/Application Support/dev.hnet.client.key"
    echo "HNET helper and client key removed"
else
    echo "HNET helper removed (client key kept; use --purge to delete)"
fi
