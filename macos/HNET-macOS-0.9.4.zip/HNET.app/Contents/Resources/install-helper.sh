#!/bin/sh
set -e
HELPER="$1"
APPUID="$2"
DEST="/Library/PrivilegedHelperTools/dev.hnet.helper"
PLIST="/Library/LaunchDaemons/dev.hnet.helper.plist"
UIDFILE="/Library/Application Support/dev.hnet.uid"

[ -n "$HELPER" ] || { echo "helper path missing"; exit 1; }
[ -n "$APPUID" ] || { echo "uid missing"; exit 1; }

launchctl bootout system "$PLIST" 2>/dev/null || true
rm -f "$DEST" "$PLIST"
mkdir -p /Library/PrivilegedHelperTools "/Library/Application Support"
install -m 755 -o root -g wheel "$HELPER" "$DEST"
cp "$(dirname "$0")/dev.hnet.helper.plist" "$PLIST"
chown root:wheel "$PLIST"
chmod 644 "$PLIST"
printf '%s\n' "$APPUID" > "$UIDFILE"
chown root:wheel "$UIDFILE"
chmod 644 "$UIDFILE"
launchctl bootstrap system "$PLIST"
launchctl enable system/dev.hnet.helper
launchctl kickstart -k system/dev.hnet.helper
sleep 1
launchctl print system/dev.hnet.helper >/dev/null 2>&1
echo "HNET helper installed"
